<?php
return array(
		//'messagephone' => '8618501735705',//开发测试的
);