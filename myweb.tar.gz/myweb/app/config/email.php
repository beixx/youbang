<?php
return array(
		'subject' => '网站发送的验证码',
);