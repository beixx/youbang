@extends('admin.base')
@section('content')
 
<div id="content" class="clearfix">
            <div class="contentwrapper"><!--Content wrapper-->

                <div class="heading">

                    

                </div><!-- End .heading-->

                <!-- Build page from here: -->
                <div class="row-fluid">

                    <div class="span12">

                        <div class="page-header">
                            <h4>{{ $name }}</h4>
                        </div>

                        <form class="form-horizontal seperator"  action="{{ url('shop/savestyle') }}" method="post" id="loginForm" enctype="multipart/form-data" />
                           
                            <input class="span4" id="username" type="hidden" name='id' value="{{ $id }}" />
                    
                            <div class="form-row row-fluid">
                                <div class="span12">
                                    <div class="row-fluid">
                                        <label class="form-label span2" for="username">风格名称</label>
                                        <input class="span4" id="username" type="text" name='name' value="" /><div><font color='red'></font></div>
                                    </div>
                                </div>
                            </div>
                            
                            
                            <div class="form-row row-fluid">        
                                <div class="span12">
                                    <div class="row-fluid">
                                        <div class="form-actions">
                                        <div class="span2"></div>
                                        <div class="span4 controls">
                                            <button type="submit" class="btn btn-info marginR10">保存</button>
                                        </div>
                                        </div>
                                    </div>
                                </div>   
                            </div>
                    	</form>
                    	
                            

                            
                            
                            
                            
                           
                        
                      
                    </div><!-- End .span12 -->

                </div><!-- End .row-fluid -
                
            </div><!-- End contentwrapper -->
        </div>
<script type="text/javascript">
var bt=baidu.template;
var Result = {};
Result['list'] = QYtype;
//最简使用方法
var html=bt('optionlist',Result);
//渲染
document.getElementById('sel').innerHTML=html;
</script>
@stop
