<?php
class Yfcstyle extends Eloquent{
	protected $table = 'yfc_style';
    public $timestamps = false;
}