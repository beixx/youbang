<?php
class Yfcbespokeview extends Eloquent{
	protected $table = 'yfc_bespoke_view';
    public $timestamps = false;
}