<?php
class Yfcroleadmin extends Eloquent{
	protected $table = 'yfc_role_admin';
    public $timestamps = false;
}