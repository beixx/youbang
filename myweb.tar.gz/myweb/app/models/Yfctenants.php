<?php
class Yfctenants extends Eloquent{
	protected $table = 'yfc_tenants';
    public $timestamps = false;
}