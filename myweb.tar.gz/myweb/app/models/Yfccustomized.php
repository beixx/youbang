<?php
class Yfccustomized extends Eloquent{
	protected $table = 'yfc_customized';
    public $timestamps = false;
}