<?php
class Yfcdaysearch extends Eloquent{
	protected $table = 'yfc_day_search';
    public $timestamps = false;
}