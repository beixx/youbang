<?php
class Yfctenantsset extends Eloquent{
	protected $table = 'yfc_tenants_set';
    public $timestamps = false;
}