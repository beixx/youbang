<?php
class Category extends Eloquent{
	protected $table = 'category';
    public $timestamps = false;
}