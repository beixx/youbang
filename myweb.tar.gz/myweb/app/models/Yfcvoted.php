<?php
class Yfcvoted extends Eloquent{
	protected $table = 'yfc_voted';
    public $timestamps = false;
}