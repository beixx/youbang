<?php
class Yfcrole extends Eloquent{
	protected $table = 'yfc_role';
    public $timestamps = false;
}