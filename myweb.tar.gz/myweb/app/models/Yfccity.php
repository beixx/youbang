<?php
class Yfccity extends Eloquent{
	protected $table = 'yfc_city';
    public $timestamps = false;
}