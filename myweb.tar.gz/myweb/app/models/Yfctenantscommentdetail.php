<?php
class Yfctenantscommentdetail extends Eloquent{
	protected $table = 'yfc_tenants_comment_detail';
    public $timestamps = false;
}