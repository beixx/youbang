<?php
class Yfcnode extends Eloquent{
	protected $table = 'yfc_node';
    public $timestamps = false;
}