<?php
class Yfctenantsdata extends Eloquent{
	protected $table = 'yfc_tenants_data';
    public $timestamps = false;
}