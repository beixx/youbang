<?php
class Yfcaccess extends Eloquent{
	protected $table = 'yfc_access';
    public $timestamps = false;
}