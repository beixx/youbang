<?php
class Yfctenantscomment extends Eloquent{
	protected $table = 'yfc_tenants_comment';
    public $timestamps = false;
}