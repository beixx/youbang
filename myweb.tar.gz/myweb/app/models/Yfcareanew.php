<?php
class Yfcareanew extends Eloquent{
	protected $table = 'yfc_area_new';
    public $timestamps = false;
}