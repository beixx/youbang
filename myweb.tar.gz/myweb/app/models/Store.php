<?php
class Store extends Eloquent{
	protected $table = 'store';
    public $timestamps = false;
}