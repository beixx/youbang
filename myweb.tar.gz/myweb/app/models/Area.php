<?php
class Area extends Eloquent{
	protected $table = 'area';
    public $timestamps = false;
}