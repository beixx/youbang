<?php
class Yfcadmin extends Eloquent{
	protected $table = 'yfc_admin';
    public $timestamps = false;
}