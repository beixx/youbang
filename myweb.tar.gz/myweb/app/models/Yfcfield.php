<?php
class Yfcfield extends Eloquent{
	protected $table = 'yfc_field';
    public $timestamps = false;
}