<?php
class Yfcprovince extends Eloquent{
	protected $table = 'yfc_province';
    public $timestamps = false;
}