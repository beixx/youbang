<?php
class Yfcuser extends Eloquent{
	protected $table = 'yfc_user';
    public $timestamps = false;
}