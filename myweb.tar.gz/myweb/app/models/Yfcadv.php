<?php
class Yfcadv extends Eloquent{
	protected $table = 'yfc_adv';
    public $timestamps = false;
}