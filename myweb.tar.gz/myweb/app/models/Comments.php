<?php
class Comments extends Eloquent{
	protected $table = 'comments';
    public $timestamps = false;
}