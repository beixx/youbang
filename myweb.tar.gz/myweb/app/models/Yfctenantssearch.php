<?php
class Yfctenantssearch extends Eloquent{
	protected $table = 'yfc_tenants_search';
    public $timestamps = false;
}