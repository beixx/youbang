<?php
class Yfcinput extends Eloquent{
	protected $table = 'yfc_input';
    public $timestamps = false;
}