<?php
class Yfcmodel extends Eloquent{
	protected $table = 'yfc_model';
    public $timestamps = false;
}